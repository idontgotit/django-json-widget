=======
Credits
=======

Development Lead
----------------

* José Manuel Rivas (jmrivas86) <jmrivas86@gmail.com>

Contributors
------------

* Knut Hühne (k-nut) <knut@k-nut.eu>
* Qiying Wang (WqyJh) <781345688@qq.com>
* Erkin Çakar (travijuu)
